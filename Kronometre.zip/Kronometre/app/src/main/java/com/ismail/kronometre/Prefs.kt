package com.ismail.kronometre

import android.content.Context

data class Config(
    val targetM: Int,        // hedef mesafe (m)
    val targetS: Int,        // hedef süre (sn)
    val timeIntervalS: Int,  // kaç saniyede bir bildirim (0 = kapalı)
    val distIntervalM: Int,  // kaç metrede bir bildirim (0 = kapalı)
    val pace: Boolean        // tahmini bitiş / önde-geride bilgisi
)

object Prefs {
    private const val NAME = "kronometre"

    fun load(c: Context): Config {
        val p = c.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        return Config(
            p.getInt("targetM", 3000),
            p.getInt("targetS", 25 * 60 + 20),
            p.getInt("timeInt", 120),
            p.getInt("distInt", 500),
            p.getBoolean("pace", true)
        )
    }

    fun save(c: Context, cfg: Config) {
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit()
            .putInt("targetM", cfg.targetM)
            .putInt("targetS", cfg.targetS)
            .putInt("timeInt", cfg.timeIntervalS)
            .putInt("distInt", cfg.distIntervalM)
            .putBoolean("pace", cfg.pace)
            .apply()
    }

    fun flag(c: Context, key: String): Boolean =
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean(key, false)

    fun setFlag(c: Context, key: String) =
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean(key, true).apply()
}

object Fmt {
    fun clock(ms: Long): String {
        val s = (if (ms < 0) -ms else ms) / 1000
        val sign = if (ms < 0) "-" else ""
        return "%s%02d:%02d".format(sign, s / 60, s % 60)
    }

    /** Sesli okuma için: "5 dakika 12 saniye" */
    fun speakDur(sec: Long): String {
        val m = sec / 60
        val s = sec % 60
        return when {
            m > 0 && s > 0 -> "$m dakika $s saniye"
            m > 0 -> "$m dakika"
            else -> "$s saniye"
        }
    }

    /** Sesli okuma için 10 m'ye yuvarlanmış: "1 kilometre 150 metre" */
    fun speakDist(m: Double): String {
        val r = (Math.round(m / 10.0) * 10).toInt()
        val km = r / 1000
        val mm = r % 1000
        return when {
            km > 0 && mm > 0 -> "$km kilometre $mm metre"
            km > 0 -> "$km kilometre"
            else -> "$mm metre"
        }
    }
}
