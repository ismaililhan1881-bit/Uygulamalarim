package com.ismail.kronometre

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.Locale
import kotlin.math.max

class RunService : Service(), LocationListener, TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_START = "com.ismail.kronometre.START"
        const val ACTION_STOP = "com.ismail.kronometre.STOP"
        private const val CH = "run"
        private const val NID = 1

        // Arayüzün okuduğu anlık durum
        @Volatile var running = false
        @Volatile var elapsedMs = 0L
        @Volatile var distanceM = 0.0
        @Volatile var accuracy = -1f
        @Volatile var finishedMs = -1L
        @Volatile var ttsProblem: String? = null
    }

    private lateinit var cfg: Config
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var lm: LocationManager
    private lateinit var audio: AudioManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pending = ArrayList<String>()
    private var focusReq: AudioFocusRequest? = null
    private var uttId = 0

    private var startRt = 0L
    private var lastLoc: Location? = null
    private var nextTimeS = 0L
    private var nextDistM = 0.0
    private var lastReportS = -999L
    private var overtimeSaid = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Koşu", NotificationManager.IMPORTANCE_LOW)
        )
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopRun()
            return START_NOT_STICKY
        }
        if (!running) startRun()
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun startRun() {
        cfg = Prefs.load(this)
        running = true
        elapsedMs = 0; distanceM = 0.0; finishedMs = -1; accuracy = -1f
        lastLoc = null; overtimeSaid = false; lastReportS = -999
        nextTimeS = cfg.timeIntervalS.toLong()
        nextDistM = cfg.distIntervalM.toDouble()

        ServiceCompat.startForeground(
            this, NID, buildNotification(),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        )

        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "kronometre:run")
            .apply { acquire(3 * 60 * 60 * 1000L) }

        startRt = SystemClock.elapsedRealtime()
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
        } catch (e: Exception) {
            speak("Konum alınamıyor.")
        }
        speak("Başladı.")
        handler.post(tick)
    }

    private fun stopRun() {
        running = false
        handler.removeCallbacks(tick)
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        wakeLock?.let { if (it.isHeld) it.release() }
        tts?.shutdown()
        abandonFocus()
        super.onDestroy()
    }

    // ---------- Zamanlayıcı ----------
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            elapsedMs = SystemClock.elapsedRealtime() - startRt
            val sec = elapsedMs / 1000
            if (finishedMs < 0) {
                if (cfg.timeIntervalS > 0 && sec >= nextTimeS) {
                    nextTimeS += cfg.timeIntervalS
                    report(sec)
                }
                if (!overtimeSaid && sec >= cfg.targetS) {
                    overtimeSaid = true
                    speak("Hedef süre doldu.")
                }
            }
            updateNotification()
            handler.postDelayed(this, 1000 - (elapsedMs % 1000) + 5)
        }
    }

    // ---------- Konum ----------
    override fun onLocationChanged(loc: Location) {
        accuracy = if (loc.hasAccuracy()) loc.accuracy else -1f
        if (!running || finishedMs >= 0) return
        if (!loc.hasAccuracy() || loc.accuracy > 25f) return   // zayıf fix'i at

        val prev = lastLoc
        if (prev == null) { lastLoc = loc; return }

        val d = prev.distanceTo(loc)
        val dt = (loc.elapsedRealtimeNanos - prev.elapsedRealtimeNanos) / 1e9
        if (dt <= 0) return
        if (d / dt > 9.0) return                                // >32 km/s sıçrama = GPS hatası
        val threshold = max(3f, (prev.accuracy + loc.accuracy) / 4f)
        if (d < threshold) return                               // yerinde titreşimi sayma

        distanceM += d
        lastLoc = loc

        elapsedMs = SystemClock.elapsedRealtime() - startRt
        val sec = elapsedMs / 1000

        if (distanceM >= cfg.targetM) {
            finishedMs = elapsedMs
            val diff = cfg.targetS - sec
            val verdict = if (diff >= 0) "Hedefin ${Fmt.speakDur(diff)} altında."
                          else "Hedefin ${Fmt.speakDur(-diff)} üstünde."
            speak("Hedef mesafe tamamlandı. Süre ${Fmt.speakDur(sec)}. $verdict")
            return
        }
        if (cfg.distIntervalM > 0 && distanceM >= nextDistM) {
            while (nextDistM <= distanceM) nextDistM += cfg.distIntervalM
            report(sec)
        }
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { if (running) speak("GPS kapandı.") }
    @Deprecated("eski API uyumluluğu")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    // ---------- Rapor ----------
    private fun report(sec: Long) {
        if (sec - lastReportS < 20) return      // süre ve mesafe bildirimi çakışırsa tekrar etme
        lastReportS = sec
        val remS = cfg.targetS - sec
        val remD = max(0.0, cfg.targetM - distanceM)
        val sb = StringBuilder()
        sb.append("Süre ${Fmt.speakDur(sec)}. ")
        if (remS >= 0) sb.append("Kalan ${Fmt.speakDur(remS)}. ")
        else sb.append("Hedef süre ${Fmt.speakDur(-remS)} aşıldı. ")
        sb.append("Mesafe ${Fmt.speakDist(distanceM)}. Kalan ${Fmt.speakDist(remD)}.")
        if (cfg.pace && distanceM >= 200) {
            val proj = (sec * cfg.targetM / distanceM).toLong()
            val diff = cfg.targetS - proj
            sb.append(" Tahmini bitiş ${Fmt.speakDur(proj)}, ")
            sb.append(if (diff >= 0) "${Fmt.speakDur(diff)} öndesin." else "${Fmt.speakDur(-diff)} gerisin.")
        }
        speak(sb.toString())
    }

    // ---------- Ses ----------
    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) { ttsProblem = "Ses motoru başlatılamadı"; return }
        val r = t.setLanguage(Locale("tr", "TR"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            ttsProblem = "Türkçe ses paketi yüklü değil"
        } else ttsProblem = null
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { if (tts?.isSpeaking != true) abandonFocus() }
            @Deprecated("") override fun onError(id: String?) { abandonFocus() }
        })
        ttsReady = true
        pending.forEach { speak(it) }
        pending.clear()
    }

    private fun speak(text: String) {
        val t = tts
        if (!ttsReady || t == null) { pending.add(text); return }
        requestFocus()
        t.speak(text, TextToSpeech.QUEUE_ADD, null, "u${uttId++}")
    }

    private fun requestFocus() {
        if (focusReq != null) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            ).build()
        audio.requestAudioFocus(req)
        focusReq = req
    }

    private fun abandonFocus() {
        focusReq?.let { audio.abandonAudioFocusRequest(it) }
        focusReq = null
    }

    // ---------- Bildirim ----------
    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, RunService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = "Süre ${Fmt.clock(elapsedMs)}  •  %.2f km".format(distanceM / 1000)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Kronometre çalışıyor")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_media_pause, "Durdur", stop)
            .build()
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NID, buildNotification())
    }
}
