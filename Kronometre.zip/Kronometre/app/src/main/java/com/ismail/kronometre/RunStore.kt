package com.ismail.kronometre

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class RunRecord(
    val date: Long,          // başlangıç zamanı (epoch ms)
    val targetM: Int,
    val targetS: Int,
    val distanceM: Double,
    val timeMs: Long,        // bitirdiyse hedef mesafedeki süre, bitirmediyse durdurma anı
    val finished: Boolean,
    val splits: List<Long>   // her 1000 m'deki KÜMÜLATİF süre (ms)
) {
    /** Her kilometrenin kendi süresi (ms) */
    fun kmTimes(): List<Long> = splits.mapIndexed { i, t -> if (i == 0) t else t - splits[i - 1] }
}

object RunStore {
    private const val FILE = "kosular"
    private const val KEY = "list"

    fun all(c: Context): List<RunRecord> {
        val raw = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val out = ArrayList<RunRecord>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val sp = o.optJSONArray("splits") ?: JSONArray()
            out += RunRecord(
                o.getLong("date"), o.getInt("targetM"), o.getInt("targetS"),
                o.getDouble("distanceM"), o.getLong("timeMs"), o.getBoolean("finished"),
                (0 until sp.length()).map { sp.getLong(it) }
            )
        }
        return out.sortedByDescending { it.date }
    }

    fun add(c: Context, r: RunRecord) = save(c, all(c) + r)

    fun delete(c: Context, date: Long) = save(c, all(c).filter { it.date != date })

    private fun save(c: Context, list: List<RunRecord>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("date", r.date); put("targetM", r.targetM); put("targetS", r.targetS)
                put("distanceM", r.distanceM); put("timeMs", r.timeMs); put("finished", r.finished)
                put("splits", JSONArray(r.splits))
            })
        }
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
