package com.ismail.kronometre

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.max

class MainActivity : AppCompatActivity(), LocationListener {

    private lateinit var tvElapsed: TextView
    private lateinit var tvRemain: TextView
    private lateinit var tvDist: TextView
    private lateinit var tvGps: TextView
    private lateinit var btnStart: Button
    private lateinit var btnBattery: Button
    private lateinit var etTargetM: EditText
    private lateinit var etTargetT: EditText
    private lateinit var etTimeInt: EditText
    private lateinit var etDistInt: EditText
    private lateinit var cbPace: CheckBox

    private lateinit var lm: LocationManager
    private val ui = Handler(Looper.getMainLooper())
    private var warmAcc = -1f
    private var warming = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lm = getSystemService(LOCATION_SERVICE) as LocationManager

        tvElapsed = findViewById(R.id.tvElapsed)
        tvRemain = findViewById(R.id.tvRemain)
        tvDist = findViewById(R.id.tvDist)
        tvGps = findViewById(R.id.tvGps)
        btnStart = findViewById(R.id.btnStart)
        btnBattery = findViewById(R.id.btnBattery)
        etTargetM = findViewById(R.id.etTargetM)
        etTargetT = findViewById(R.id.etTargetT)
        etTimeInt = findViewById(R.id.etTimeInt)
        etDistInt = findViewById(R.id.etDistInt)
        cbPace = findViewById(R.id.cbPace)

        val c = Prefs.load(this)
        etTargetM.setText(c.targetM.toString())
        etTargetT.setText("%d:%02d".format(c.targetS / 60, c.targetS % 60))
        etTimeInt.setText(c.timeIntervalS.toString())
        etDistInt.setText(c.distIntervalM.toString())
        cbPace.isChecked = c.pace

        btnStart.setOnClickListener { if (RunService.running) stopRun() else startRun() }
        btnBattery.setOnClickListener { askBattery() }

        requestPerms()
        if (!Prefs.flag(this, "batteryAsked")) { Prefs.setFlag(this, "batteryAsked"); askBattery() }
    }

    override fun onResume() {
        super.onResume()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startWarm()
        ui.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        stopWarm()
        ui.removeCallbacks(refresh)
    }

    // ---------- Başlat / Durdur ----------
    private fun startRun() {
        if (!hasLoc()) { requestPerms(); toast("Konum izni gerekli"); return }
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            toast("GPS kapalı, açın"); startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); return
        }
        val cfg = readConfig() ?: return
        Prefs.save(this, cfg)
        stopWarm()
        ContextCompat.startForegroundService(
            this, Intent(this, RunService::class.java).setAction(RunService.ACTION_START)
        )
    }

    private fun stopRun() {
        startService(Intent(this, RunService::class.java).setAction(RunService.ACTION_STOP))
    }

    private fun readConfig(): Config? {
        val m = etTargetM.text.toString().trim().toIntOrNull()
        val parts = etTargetT.text.toString().trim().split(":")
        val t = if (parts.size == 2) {
            val mm = parts[0].toIntOrNull(); val ss = parts[1].toIntOrNull()
            if (mm != null && ss != null) mm * 60 + ss else null
        } else parts[0].toIntOrNull()?.times(60)
        val ti = etTimeInt.text.toString().trim().ifEmpty { "0" }.toIntOrNull()
        val di = etDistInt.text.toString().trim().ifEmpty { "0" }.toIntOrNull()
        if (m == null || m <= 0 || t == null || t <= 0 || ti == null || ti < 0 || di == null || di < 0) {
            toast("Ayarları kontrol et (süre biçimi dk:sn)"); return null
        }
        return Config(m, t, ti, di, cbPace.isChecked)
    }

    // ---------- Arayüz yenileme ----------
    private val refresh = object : Runnable {
        override fun run() {
            val cfg = Prefs.load(this@MainActivity)
            val running = RunService.running
            val el = if (RunService.finishedMs >= 0) RunService.finishedMs else RunService.elapsedMs
            val d = RunService.distanceM

            tvElapsed.text = Fmt.clock(RunService.elapsedMs)
            tvRemain.text = "Kalan süre: " + Fmt.clock(cfg.targetS * 1000L - RunService.elapsedMs)
            tvDist.text = "%.0f m  •  kalan %.0f m".format(d, max(0.0, cfg.targetM - d)) +
                if (RunService.finishedMs >= 0) "\nBİTİŞ: ${Fmt.clock(el)}" else ""

            val acc = if (running) RunService.accuracy else warmAcc
            val gps = when {
                !hasLoc() -> "Konum izni yok"
                acc < 0 -> "GPS aranıyor…"
                acc <= 10 -> "GPS iyi (±%.0f m)".format(acc)
                acc <= 25 -> "GPS orta (±%.0f m)".format(acc)
                else -> "GPS zayıf (±%.0f m) — açık alanda bekle".format(acc)
            }
            tvGps.text = gps + (RunService.ttsProblem?.let { "\n⚠ $it" } ?: "")

            btnStart.text = if (running) "DURDUR" else "BAŞLAT"
            listOf(etTargetM, etTargetT, etTimeInt, etDistInt, cbPace).forEach { it.isEnabled = !running }

            val pm = getSystemService(POWER_SERVICE) as PowerManager
            btnBattery.visibility = if (pm.isIgnoringBatteryOptimizations(packageName))
                android.view.View.GONE else android.view.View.VISIBLE

            if (!running && !warming) startWarm()
            ui.postDelayed(this, 500)
        }
    }

    // ---------- GPS ısınma (başlatmadan önce fix yakalamak için) ----------
    @SuppressLint("MissingPermission")
    private fun startWarm() {
        if (warming || RunService.running || !hasLoc()) return
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
            warming = true
        } catch (_: Exception) {}
    }

    private fun stopWarm() {
        if (!warming) return
        lm.removeUpdates(this); warming = false
    }

    override fun onLocationChanged(loc: Location) { warmAcc = if (loc.hasAccuracy()) loc.accuracy else -1f }
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) { warmAcc = -1f }
    @Deprecated("eski API uyumluluğu")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    // ---------- İzinler ----------
    private fun hasLoc() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val need = mutableListOf<String>()
        if (!hasLoc()) {
            need += Manifest.permission.ACCESS_FINE_LOCATION
            need += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) ActivityCompat.requestPermissions(this, need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        startWarm()
    }

    @SuppressLint("BatteryLife")
    private fun askBattery() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
