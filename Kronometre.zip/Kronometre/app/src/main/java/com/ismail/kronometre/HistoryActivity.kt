package com.ismail.kronometre

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var box: LinearLayout
    private val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(16); setPadding(p, p, p, p)
        }
        setContentView(ScrollView(this).apply { addView(box) })
        render()
    }

    private fun render() {
        box.removeAllViews()
        val runs = RunStore.all(this)
        if (runs.isEmpty()) { box.addView(text("Henüz kayıt yok.", 18f)); return }

        // Karşılaştırma yalnızca aynı hedef mesafedeki tamamlanmış koşular arasında
        val done = runs.filter { it.finished }
        val best = done.minByOrNull { it.timeMs }
        val bestKm = HashMap<Int, Long>()
        done.forEach { r -> r.kmTimes().forEachIndexed { i, t ->
            if (t < (bestKm[i] ?: Long.MAX_VALUE)) bestKm[i] = t } }

        if (best != null) {
            val sb = StringBuilder("EN İYİ: ${Fmt.clock(best.timeMs)}  (${df.format(Date(best.date))})")
            if (bestKm.isNotEmpty()) {
                sb.append("\nEn iyi km'ler: ")
                sb.append(bestKm.keys.sorted().joinToString("  ") { "${it + 1}. ${Fmt.clock(bestKm[it]!!)}" })
            }
            if (done.size > 1) {
                val avg = done.map { it.timeMs }.average().toLong()
                sb.append("\nOrtalama: ${Fmt.clock(avg)}  •  ${done.size} tamamlanmış koşu")
            }
            box.addView(text(sb.toString(), 17f, bold = true))
        }
        box.addView(text("Silmek için kayda uzun bas.", 13f).apply { alpha = 0.6f })

        runs.forEach { r ->
            val sb = StringBuilder()
            sb.append(df.format(Date(r.date))).append('\n')
            if (r.finished) {
                val diff = r.targetS - r.timeMs / 1000
                sb.append("${r.targetM} m  •  ${Fmt.clock(r.timeMs)}  ")
                sb.append(if (diff >= 0) "✓ hedefin ${Fmt.clock(diff * 1000)} altında"
                          else "✗ hedefin ${Fmt.clock(-diff * 1000)} üstünde")
                if (best != null && r !== best) sb.append("\nEn iyiye göre +${Fmt.clock(r.timeMs - best.timeMs)}")
            } else {
                sb.append("Tamamlanmadı: %.0f m  •  %s".format(r.distanceM, Fmt.clock(r.timeMs)))
            }
            val km = r.kmTimes()
            if (km.isNotEmpty()) {
                sb.append('\n')
                sb.append(km.mapIndexed { i, t ->
                    "${i + 1}. km ${Fmt.clock(t)}" + if (bestKm[i] == t && done.size > 1) "★" else ""
                }.joinToString("   "))
            }
            val tv = text(sb.toString(), 16f)
            tv.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setMessage("${df.format(Date(r.date))} kaydı silinsin mi?")
                    .setPositiveButton("Sil") { _, _ -> RunStore.delete(this, r.date); render() }
                    .setNegativeButton("Vazgeç", null).show()
                true
            }
            box.addView(divider())
            box.addView(tv)
        }
    }

    private fun text(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun divider() = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1))
        setBackgroundColor(0x40808080)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
