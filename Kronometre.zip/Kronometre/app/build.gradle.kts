plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ismail.kronometre"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ismail.kronometre"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    signingConfigs {
        create("sabit") {
            storeFile = file("kronometre.jks")
            storePassword = "kronometre"
            keyAlias = "kronometre"
            keyPassword = "kronometre"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("sabit") }
        release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("sabit") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
